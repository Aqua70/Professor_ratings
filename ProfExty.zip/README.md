# Professor Rating Finder
A chrome extension which automatically finds ratings for professors when you enroll on your UofT acorn.
